/*
    DROP PROCESS TAG
*/
drop table if exists tags
drop type if exists tag_type_enum;
