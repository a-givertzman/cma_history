read -r -d '' sql << EOF
    drop view if exists event_view;
EOF